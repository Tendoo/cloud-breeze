<?php
/**
 * Foo module Model
 * @since  2.0
**/
namespace Modules\Foo\Models;

use Illuminate\Database\Eloquent\Model;

class Orders extends Model
{
    //
}