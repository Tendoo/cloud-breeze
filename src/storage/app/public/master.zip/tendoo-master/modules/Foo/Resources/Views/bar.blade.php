@extends( 'components.backend.dashboard.master' )
@section( 'components.backend.dashboard.master.body' )
Hello
@endsection