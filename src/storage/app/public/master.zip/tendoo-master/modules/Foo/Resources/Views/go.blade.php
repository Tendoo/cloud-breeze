@extends( 'components.backend.dashboard.master' )
@section( 'components.backend.dashboard.master.body' )
This is for Go Page :)
@endsection