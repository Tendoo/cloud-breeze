<{{ '?php' }}
/**
 * {{ $module[ 'name'] }} Model
 * @since {{ $module[ 'version' ] }}
**/
namespace Modules\{{ $module[ 'namespace' ] }}\Models;

use Illuminate\Database\Eloquent\Model;

class {{ ucwords( $name ) }} extends Model
{
    //
}