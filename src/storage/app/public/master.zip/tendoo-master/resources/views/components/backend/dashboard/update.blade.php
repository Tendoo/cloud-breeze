@extends( 'components.backend.dashboard.master' )
@section( 'components.backend.dashboard.master.body' )
    <h3>Update Section</h3>
@endsection