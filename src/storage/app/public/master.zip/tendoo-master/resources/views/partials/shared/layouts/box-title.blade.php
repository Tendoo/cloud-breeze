<div class="card-header p-0">
    <h5 class="box-title">Some Title</h5>
</div>