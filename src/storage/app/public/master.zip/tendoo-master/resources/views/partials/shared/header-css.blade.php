<link rel="stylesheet" href="{{ asset( 'bower_components/bootstrap-material-design/css/bootstrap-material-design.min.css' ) }}">
<link rel="stylesheet" href="{{ asset( 'css/shared.css' ) }}">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">
