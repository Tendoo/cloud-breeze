<div class="card card-body">
    <h4>{{ sprintf( __( 'Unable to load the view : %s' ), $view ) }}</h4>
</div>