@extends( 'components.backend.dashboard.master' )
@section( 'components.backend.dashboard.master.body' )
    @include( 'partials.shared.tables-boxed' )
@endsection