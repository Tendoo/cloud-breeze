<{{ '?' }}xml version="1.0" {{ '?' }}>
<module>
    <namespace>{{ $module[ 'namespace' ] }}</namespace>
    <version>{{ $module[ 'version' ] }}</version>
    <author>{{ $module[ 'author' ] }}</author>
    <name>{{ $module[ 'name' ] }}</name>
    <description>{{ $module[ 'description' ] }}</description>
</module>
