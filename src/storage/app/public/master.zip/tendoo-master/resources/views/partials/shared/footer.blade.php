</body>
@yield( 'partials.shared.footer' )
@stack( 'partials.shared.footer' )
</html>