<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header p-0 d-flex justify-content-between">
                <div class="card-heading p-2">
                    Some Box
                </div>
                <div class="card-buttons d-flex flex-row">
                    <div class="card-header-buttons p-2">
                        <i class="material-icons">close</i>
                    </div>
                    <div class="card-header-buttons p-2">
                        <i class="material-icons">close</i>
                    </div>
                </div>
            </div>
            <div class="card-body">Another Box</div>
        </div>
    </div>
</div>